void main() {
  print('    *       ');
  print('   * *      ');
  print('  * * *     ');
  print(' * * * *    ');
}

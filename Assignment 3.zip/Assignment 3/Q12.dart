void main() {
  String sequence = '';
  for (int i = 1; i < 5; i++) {
    sequence = sequence + i.toString();
    print(sequence);
  }
}

void main() {
  var num = 5;
  var factorial = 1;

  while (num >= 1) {
    factorial = factorial * num;
    //1 * 5 =5
    //1* 4=4   then add all it makes 120
    num--;

    ///num=4
  }
  print("factorial of 5 is $factorial");
}

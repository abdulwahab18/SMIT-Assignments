void main() {
  int number = 5;
  for (int a = 1; a <= 10; a++) {
    print('$number x  $a = ${number * a}');
  }
}
